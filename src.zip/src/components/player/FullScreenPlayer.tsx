'use client';

import type { FC } from 'react';
import { useState, useEffect, useRef } from 'react';

import Image from 'next/image';
import {
  ChevronDown,
  MoreVertical,
  Heart,
  PlusCircle,
  Shuffle,
  SkipBack,
  Play,
  Pause,
  SkipForward,
  Repeat,
  LaptopMinimal,
  Share2,
  ListMusic,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePlayer } from '@/contexts/PlayerContext';
import styles from './FullScreenPlayer.module.css';
import styles2 from './sounds.module.css'
const FullScreenPlayer: FC = () => {
  const { currentTrack, isPlaying, togglePlayPause, setIsPlayerOpen, audioElementRef } = usePlayer();
  const [currentTime, setCurrentTime] = useState(0);
  const [isMetadataLoaded, setIsMetadataLoaded] = useState(false);
  const [duration, setDuration] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isShuffleActive, setIsShuffleActive] = useState(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'one' | 'all'>('off');

  const progressBarContainerRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    const audio = audioElementRef.current;
    if (audio) {
      const updateTimes = () => {
        setCurrentTime(audio.currentTime);
        setDuration(audio.duration || 0);
      };
      const handleLoadedMetadata = () => {
        setDuration(audio.duration || 0);
        setCurrentTime(audio.currentTime || 0);
      };

      audio.addEventListener('timeupdate', updateTimes);
      audio.addEventListener('loadedmetadata', handleLoadedMetadata);

      if (audio.readyState >= audio.HAVE_METADATA) {
        handleLoadedMetadata();
      }
      if (audio.readyState >= audio.HAVE_CURRENT_DATA) {
        updateTimes();
      }

      return () => {
        audio.removeEventListener('timeupdate', updateTimes);
        audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      };
    }
  }, [audioElementRef, currentTrack]);


  if (!currentTrack) {
    return null;
  }

  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds) || timeInSeconds === Infinity || timeInSeconds < 0) {
      return '0:00';
    }
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const handleProgressChange = (event: React.MouseEvent<HTMLDivElement>) => {
    if (audioElementRef.current && progressBarContainerRef.current && duration > 0) {
      const progressBar = progressBarContainerRef.current;
      const clickPositionInPixels = event.clientX - progressBar.getBoundingClientRect().left;
      const clickPositionInPercentage = clickPositionInPixels / progressBar.offsetWidth;
      const newTime = duration * clickPositionInPercentage;
      audioElementRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleLike = () => setIsLiked(!isLiked);
  const handleShuffle = () => setIsShuffleActive(!isShuffleActive);
  const handleRepeat = () => {
    setRepeatMode(prev => {
      if (prev === 'off') return 'all';
      if (prev === 'all') return 'one';
      return 'off';
    });
     if (audioElementRef.current) {
      if (repeatMode === 'one') audioElementRef.current.loop = true; // for 'one'
      else audioElementRef.current.loop = false; // for 'off' and 'all' (handled by 'ended' event for 'all')
    }
  };
  const handleRewind = () => {
    if (audioRef.current) {
      const newTime = Math.max(audioRef.current.currentTime - 10, 0);
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
      localStorage.setItem('audioCurrentTime', newTime.toString());
      localStorage.setItem('audioDuration', duration.toString());
    }
  };
    const handleSkip = () => {
    if (audioRef.current) {
      const newTime = Math.min(
        audioRef.current.currentTime + 10,
        audioRef.current.duration
      );
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
      localStorage.setItem('audioCurrentTime', newTime.toString());
      localStorage.setItem('audioDuration', duration.toString());
    }
  };
    const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
      if (!progressBarRef.current) return;
      
      const rect = progressBarRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.min(Math.max(x / rect.width, 0), 1);
      const newTime = percentage * duration;
      onSeek(newTime);
    };
    

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-neutral-700 via-neutral-800 to-neutral-900 text-white flex flex-col z-[100] overflow-hidden">


       <div className="play-c-herospace-container">
                <section
                  className="sc-c-herospace gel-1/1 sc-u-clip-overflow"
                  aria-labelledby="sc-id-benji-b"
                >
         <div className="gel-wrap gs-u-box-size sc-o-island sc-c-herospace__container">
              <div className="sc-c-herospace__details gel-1/1 gs-u-box-size">
                <div className="gel-9/24@xl gs-u-display-inline-block@xl">
                  <div className="sc-c-herospace__imagery gs-u-display-inline-block gel-3/12 gel-2/12@l gel-10/24@xl sc-o-island gs-u-float-right@xl">

                    
                                       
        {/* Album Art */}
        <div className="flex-shrink-0 w-full max-w-xs sm:max-w-sm md:max-w-md aspect-square mx-auto my-4 shadow-2xl rounded-lg overflow-hidden">
           <picture>   <Image
            src={currentTrack.imageUrl}
            alt={`${currentTrack.title} album art`}
            width={500}
            height={500}
            className="object-cover w-full h-full"
            data-ai-hint={currentTrack.dataAiHint || "album art"}
            priority
          />
		         </picture>
        </div>
                                

                 </div></div>
                       <div className="sc-c-herospace__details gs-u-pl++@xl gel-15/24@xl gs-u-display-inline-block@xl gs-u-align-top">
                  <div className="gel-17/24@xl sc-c-herospace__details-titles gs-u-pt+ gs-u-mh++">
                    <h1 className="sc-u-screenreader-only">
                      Radio 1 - Listen Live - BBC Sounds
                    </h1>
                    <span
                      aria-label="Radio 1"
                      className="sc-c-herospace__network-title gel-long-primer-bold gs-u-display-block"
                    >
                      RADIO 1
                    </span>
                    <hr className="gs-u-mt gs-u-mb-alt gs-u-display-inline-block gs-u-ml-0@xl" />
					
                    <div>
					      <div className="flex items-center justify-between mb-6 flex-shrink-0 px-2">
          <Button variant="ghost" size="icon" onClick={() => setIsPlayerOpen(false)} className="text-white hover:bg-white/10">
            <ChevronDown className="w-7 h-7" />
          </Button>
          <div className="text-center">
            <p className="text-xs uppercase text-neutral-400">Playing from Playlist</p>
            <p className="text-sm font-semibold">{currentTrack.artist || 'Library'}</p>
          </div>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <MoreVertical className="w-6 h-6" />
          </Button>
        </div>
                      <a
                        id="sc-id-benji-b"
                        className="gel-pica-bold gs-u-display-inline-block gs-u-mb"
                        href="/programmes/b00v4tv3"
                      >
		
                      <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold truncate">{currentTrack.title}</h2>
         
            </div>
                      </a>
                      <div className="sc-c-marquee--non-touch sc-c-marquee sc-c-herospace__details-titles-secondary">
					  			    <div
              id="smp-wrapper"
              className="sc-c-smp gel-wrap play-c-player optimizely-player gs-u-mt- gs-u-pb@m gs-u-pb+@xl gs-u-pl0 gs-u-pr0"
            >        {/* Top Bar */}
  
			        {/* Song Info & Like/Add */}
        <div className="my-4 px-2 flex-shrink-0">
          <div className="flex items-center justify-between">
         
            <div className="flex items-center space-x-3 sm:space-x-4 ml-2">
              <Button variant="ghost" size="icon" onClick={handleLike} className={`text-white hover:bg-white/10 p-1 ${isLiked ? 'text-primary' : ''}`}>
                <Heart className={`w-6 h-6 sm:w-7 sm:h-7 ${isLiked ? 'fill-current text-primary' : ''}`} />
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 p-1">
                <PlusCircle className="w-6 h-6 sm:w-7 sm:h-7" />
              </Button>
            </div>
          </div>
        </div>

			</div>
                        <div
                          className="sc-c-marquee__title gel-great-primer gs-u-pb- b-font-weight-500"
                          tabIndex={0}
                        >
                          <span className="sc-c-marquee__title-1">
                       <p className="text-neutral-300 truncate">{currentTrack.artist || 'Unknown Artist'}</p>
                          </span>
                        

                        </div>
                      </div>
                    </div>
                  </div>
                </div>     
      <div
              id="smp-wrapper"
              className="sc-c-smp gel-wrap play-c-player optimizely-player gs-u-mt- gs-u-pb@m gs-u-pb+@xl gs-u-pl0 gs-u-pr0"
            >
			 <div
                style={{
                  position: "relative",
                  zIndex: 999,
                  height: "100%",
                  width: "100%",
                  paddingBottom: 0
                  
                }}
                id="smphtml5iframesmp-wrapperwrp"
              >
                      <div className={styles.mediaContainer}>
                  <div className="control-group">
				  				<div className="flex-grow flex flex-col p-4 pt-8 md:p-6 md:pt-10 overflow-y-auto">
                     <div className="p_bar p_seekBar">
          <div 
                          className={`${styles.progressBar} ${isPlaying ? styles.playingIndicator : ''}`}
                          style={{ 
                            width: `${isMetadataLoaded && duration > 0 ? (currentTime / duration) * 100 : 0}%`,
                            backgroundColor: '#ff4400'
                          }}
                        >
                          <div className={styles.seekDot} />
                        </div>
    
  </div>
    <div className="p_bar p_progressBar p_progressBarAvailable"></div>
			</div>
			
	  <div className={`${styles.progressSection} p_section`}>
            <span className={`${styles.timeStamp} p_timeStamp`}>{formatTime(currentTime)}</span>

            <div
              className={`${styles.progressBarContainer} p_progressBarContainer`}
              ref={progressBarContainerRef}
              onClick={handleProgressChange}
              role="slider"
              aria-valuenow={currentTime}
              aria-valuemin={0}
              aria-valuemax={duration}
              aria-label="Seek"
              tabIndex={0}
              onKeyDown={(e) => {
                  if (e.key === 'ArrowLeft' && audioElementRef.current) {
                      audioElementRef.current.currentTime = Math.max(0, audioElementRef.current.currentTime - 5);
                  } else if (e.key === 'ArrowRight' && audioElementRef.current) {
                      audioElementRef.current.currentTime = Math.min(duration, audioElementRef.current.currentTime + 5);
                  }
              }}
            >
              <div className={`${styles.progressBar} p_bar p_progressBar`} style={{ width: `${progressPercentage}%` }}>
                <div className={`${styles.progressBarThumb} p_button p_seekThumb`} style={{ left: `${progressPercentage}%` }}>
                  <div className="p_seekBarPositionLine" style={{
                    display: "none",
                    left: `${progressPercentage}%`,
                    position: "absolute"
                  }} />
                  <div className="p_seekThumbLine" />
                  <div className="p_seekThumbHalo" />
                </div>
              </div>
            </div>

            <span className={`${styles.timeStamp} p_timeStamp`}>{formatTime(duration)}</span>
          </div>

				               <button
                      className="audioButton p_audioui_intervalButton"
                      id="p_audioui_backInterval"
                      aria-label="Rewind 10 seconds"
                      onClick={handleRewind}
                    >
                      <div className="p_audioButton_buttonInner">
                        <svg width={48} height={48} viewBox="0 0 48 48" focusable="false">
                          <path
                            id="p_audioui_backInterval_backArrow"
                            className="p_audioui_intervalArrow"
                            d="M23.9785895,8.59327393 C23.926122,8.59327393 23.8224363,8.59327393 23.8224363,8.59327393 L22.3845769,8.5920247 L25.6962756,5.28657205 L23.9298697,3.52391381 L17.3039737,10.1348191 L23.9298697,16.7457244 L25.6962756,14.9830662 L22.4158075,11.7088442 L23.8224363,11.7113426 C23.8224363,11.7113426 23.926122,11.7100934 23.9785895,11.7100934 C31.9124254,11.7100934 38.3446914,18.1286179 38.3446914,26.0462138 C38.3446914,33.9638098 31.9124254,40.3823343 23.9785895,40.3823343 C16.0435044,40.3823343 9.61248769,33.9638098 9.61248769,26.0462138 C9.61248769,26.0299739 9.61498614,26.0149832 9.61498614,25.9987433 L6.49192052,25.9987433 C6.49192052,26.0149832 6.48942206,26.0299739 6.48942206,26.0462138 C6.48942206,35.6852436 14.3195722,43.4991538 23.9785895,43.4991538 C33.6376069,43.4991538 41.467757,35.6852436 41.467757,26.0462138 C41.467757,16.4071841 33.6376069,8.59327393 23.9785895,8.59327393"
                            focusable="false"
                          />
                        </svg>
                        <div className="p_audioui_iconNumber">10</div>
                      </div>
                    </button>
                        <button
                      className="audioButton"
                      id="p_audioui_playpause"
                      aria-label={isPlaying ? "Pause" : "Play"}
                      onClick={togglePlayPause}
                    >
                      <div className="p_audioButton_buttonInner">
                        <svg width="68" height="68" viewBox="0 0 68 68" focusable="false">
                          <circle 
                            id="p_audioui_playpause_circle" 
                            cx="34" 
                            cy="34" 
                            r="32" 
                            className={styles.base_circle}
                          />
                          <circle 
                            id="p_audioui_playpause_highlightCircle" 
                            cx="34" 
                            cy="34" 
                            r="34" 
                            className={styles.highlight_circle}
                          />
                          <polygon 
                            id="p_audioui_playpause_playIcon" 
                            points="27 46 46 34 27 22" 
                            className={styles.play_icon}
                            style={{ opacity: isPlaying ? 0 : 1 }}
                          />
                          <g 
                            id="p_audioui_playpause_pauseIcon" 
                            className={styles.pause_icon}
                            style={{ opacity: isPlaying ? 1 : 0 }}
                          >
                            <rect x="26" y="24" width="6" height="20" />
                            <rect x="36" y="24" width="6" height="20" />
                          </g>
                          
                        </svg>
                      </div>
                    </button>

                    <button
                      className="audioButton p_audioui_intervalButton"
                      id="p_audioui_forwardInterval"
                      aria-label="Skip forward 10 seconds"
                      onClick={handleSkip}
                    >
                      <div className="p_audioButton_buttonInner">
                        <svg width={48} height={48} viewBox="0 0 48 48" focusable="false">
                          <path
                            id="p_audioui_forwardInterval_forwardArrow"
                            className="p_audioui_intervalArrow"
                            d="M23.9912,8.58202C24.0435,8.58202,24.147,8.58202,24.147,8.58202L25.5817,8.58077L22.2773,5.28266L24.0398,3.52391L30.651,10.1201L28.8872,11.8801L24.0398,16.7176L22.2773,14.9576L25.5505,11.6919L24.147,11.6932C24.147,11.6932,24.0435,11.6919,23.9912,11.6919C16.075,11.6919,9.65698,18.0962,9.65698,25.9962C9.65698,33.8962,16.0737,40.3005,23.9912,40.3005C31.9074,40.3005,38.3254,33.8962,38.3254,25.9962C38.3254,25.98,38.3229,25.965,38.3229,25.9488L41.439,25.9488C41.439,25.965,41.4415,25.98,41.4415,25.9962C41.4415,35.6138,33.6288,43.4104,23.9912,43.4104C14.3536,43.4104,6.54085,35.6138,6.54085,25.9962C6.54085,16.3786,14.3536,8.58202,23.9912,8.58202"
                            focusable="false"
                          />
                        </svg>
                        <div className="p_audioui_iconNumber">10</div>
                      </div>
                    </button>
			<h1>
			Tijaabo position
			</h1>
      
			</div>
      
			</div>
			</div>
			</div>





                  <div className="flex-grow flex flex-col p-4 pt-8 md:p-6 md:pt-10 overflow-y-auto">




           <div
                style={{
                  position: "relative",
                  zIndex: 999,
                  height: "100%",
                  width: "100%",
                  paddingBottom: 0
                }}
                id="smphtml5iframesmp-wrapperwrp"
              >

        <div className={`${styles.audioPlayerContainer} my-4 flex-shrink-0 -mx-4 md:-mx-0`}>
      











          <div className={`${styles.controlsSection} p_controls`}>
            <button
              className={`${styles.controlButton} ${isShuffleActive ? styles.controlButtonActive : ''} p_button p_shuffle`}
              aria-label="Shuffle"
              onClick={handleShuffle}
            >
              <Shuffle size={20} />
            </button>
            <button
              className={`${styles.controlButton} ${styles.controlButtonSkipStyled} p_button p_previous`}
              aria-label="Previous"
              onClick={() => audioElementRef.current && (audioElementRef.current.currentTime = Math.max(0, audioElementRef.current.currentTime - 10))}
            >
              <SkipBack size={22} />
            </button>
            <button
              className={`${styles.controlButton} ${styles.controlButtonPlayPause} p_button p_playPause`}
              aria-label={isPlaying ? "Pause" : "Play"}
              onClick={togglePlayPause}
            >
              {isPlaying ? <Pause size={24} /> : <Play size={24} />}
            </button>
            <button
              className={`${styles.controlButton} ${styles.controlButtonSkipStyled} p_button p_next`}
              aria-label="Next"
              onClick={() => audioElementRef.current && (audioElementRef.current.currentTime = Math.min(duration, audioElementRef.current.currentTime + 10))}
            >
              <SkipForward size={22} />
            </button>
            <button
              className={`${styles.controlButton} ${repeatMode !== 'off' ? styles.controlButtonRepeatActive : ''} p_button p_repeat`}
              aria-label="Repeat"
              onClick={handleRepeat}
            >
              <Repeat size={20} />
              {repeatMode !== 'off' && <span className={`${styles.repeatDot} p_repeatDot`} />}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-neutral-300 px-4 mt-auto mb-2 flex-shrink-0">
          <Button variant="ghost" size="icon" className="hover:text-white">
            <LaptopMinimal className="w-5 h-5 md:w-6 md:h-6" />
          </Button>
          <div className="flex items-center space-x-6">
            <Button variant="ghost" size="icon" className="hover:text-white">
              <Share2 className="w-5 h-5 md:w-6 md:h-6" />
            </Button>
            <Button variant="ghost" size="icon" className="hover:text-white">
              <ListMusic className="w-5 h-5 md:w-6 md:h-6" />
            </Button>
          </div>
        </div></div>

        {currentTrack.artist && (
          <div className="px-2 text-center flex-shrink-0 mb-2">
            <Button
              variant="outline"
              className="rounded-full border-neutral-500 text-white hover:border-white hover:bg-white/5 px-5 py-2 text-sm font-semibold"
            >
              Explore {currentTrack.artist}
            </Button>
          </div>
        )}
        </div>
          </div>
                </div>

         </section>
         </div>
      </div>
  );
};

export default FullScreenPlayer;
