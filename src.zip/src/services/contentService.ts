// src/services/contentService.ts
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  Timestamp,
  where,
  QueryConstraint,
  Query,
  DocumentData,
  limit,
  startAfter,
  DocumentSnapshot
} from 'firebase/firestore';
import { db } from '@/lib/firebase';

export interface ContentItem {
  id: string;
  title: string;
  subtitle?: string; // Artist for audio, author/source for articles
  imageUrl: string;
  dataAiHint: string;
  category?: string; // e.g., Music, Podcast, News, Tech
  contentType: 'audio' | 'article'; // Explicit content type
  createdAt?: Timestamp;
  updatedAt?: Timestamp;

  // Audio specific
  audioSrc?: string; // URL to audio file

  // Article specific
  excerpt?: string; // Short summary
  fullBodyContent?: string; // Full HTML or Markdown content

  // Series/Episode specific
  isSeries?: boolean;      // Is this content item a parent series?
  parentId?: string;       // If an episode, ID of the parent series
  episodeNumber?: number;  // If an episode, its number in the series
  seriesTitle?: string;    // Denormalized title of the parent series for easy display
}

export interface ContentItemData extends Omit<ContentItem, 'id' | 'createdAt' | 'updatedAt'> {
  // Ensure optional fields can be explicitly set to null if needed to remove them during an update
  subtitle?: string | null;
  category?: string | null;
  audioSrc?: string | null;
  excerpt?: string | null;
  fullBodyContent?: string | null;
  isSeries?: boolean | null;
  parentId?: string | null;
  episodeNumber?: number | null;
  seriesTitle?: string | null;
}


const CONTENT_COLLECTION = 'content';

// Helper to remove undefined fields from data before sending to Firestore
const prepareDataForFirestore = <T extends Record<string, any>>(data: T): Partial<T> => {
  const firestoreData: Partial<T> = {};
  for (const key in data) {
    if (Object.prototype.hasOwnProperty.call(data, key) && data[key] !== undefined) {
      firestoreData[key as keyof T] = data[key];
    }
  }
  return firestoreData;
};


export const getContentItems = async (queryConstraints: QueryConstraint[] = [], lastVisible?: DocumentSnapshot<DocumentData> | null, pageSize: number = 20): Promise<{items: ContentItem[], newLastVisible: DocumentSnapshot<DocumentData> | null }> => {
  try {
    const contentCollectionRef = collection(db, CONTENT_COLLECTION);
    
    const finalConstraints: QueryConstraint[] = [...queryConstraints];
    const hasOrderBy = queryConstraints.some(c => (c as any)._field === 'createdAt'); // Basic check
    if (!hasOrderBy) {
        finalConstraints.push(orderBy('createdAt', 'desc'));
    }
    finalConstraints.push(limit(pageSize));

    if (lastVisible) {
        finalConstraints.push(startAfter(lastVisible));
    }
    
    const q = query(contentCollectionRef, ...finalConstraints);
    const querySnapshot = await getDocs(q);
    
    const items = querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    } as ContentItem));

    const newLastVisible = querySnapshot.docs[querySnapshot.docs.length - 1] || null;

    return { items, newLastVisible };

  } catch (error) {
    console.error('Error fetching content items:', error);
    throw error;
  }
};

export const getContentItemsByCategory = async (categoryName: string): Promise<ContentItem[]> => {
  try {
    const q = query(
      collection(db, CONTENT_COLLECTION),
      where('category', '==', categoryName),
      orderBy('createdAt', 'desc'),
      limit(50) // Example limit
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ContentItem));
  } catch (error) {
    console.error(`Error fetching content items for category ${categoryName}:`, error);
    throw error;
  }
};


export const addContentItem = async (itemData: ContentItemData): Promise<string> => {
  try {
    const preparedData = prepareDataForFirestore(itemData);
    const dataToSave = {
      ...preparedData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
    };

    if (dataToSave.episodeNumber === '' || dataToSave.episodeNumber === null || typeof dataToSave.episodeNumber === 'undefined') {
      delete dataToSave.episodeNumber;
    } else if (typeof dataToSave.episodeNumber === 'string') {
      dataToSave.episodeNumber = parseInt(dataToSave.episodeNumber, 10);
      if (isNaN(dataToSave.episodeNumber)) delete dataToSave.episodeNumber;
    }

    // Ensure boolean isSeries is set, default to false if not provided
    dataToSave.isSeries = typeof dataToSave.isSeries === 'boolean' ? dataToSave.isSeries : false;
    if (dataToSave.isSeries && dataToSave.parentId) {
        // A series cannot be an episode of another series for this data model.
        // Or, if it can, this logic might need adjustment. For now, clear parentId if it's a series.
        // console.warn("Content item marked as series but also has a parentId. Clearing parentId.");
        // delete dataToSave.parentId; 
        // delete dataToSave.episodeNumber;
        // delete dataToSave.seriesTitle;
    }


    const docRef = await addDoc(collection(db, CONTENT_COLLECTION), dataToSave);
    return docRef.id;
  } catch (error) {
    console.error('Error adding content item:', error);
    throw error;
  }
};

export const updateContentItem = async (itemId: string, itemData: Partial<ContentItemData>): Promise<void> => {
  try {
    const preparedData = prepareDataForFirestore(itemData);
    const dataToUpdate: Record<string, any> = {
      ...preparedData,
      updatedAt: Timestamp.now(),
    };
    
    if ('createdAt' in dataToUpdate) {
        delete dataToUpdate.createdAt; // Don't allow updating createdAt
    }
    
    if (dataToUpdate.episodeNumber === '' || dataToUpdate.episodeNumber === null || typeof dataToUpdate.episodeNumber === 'undefined') {
       // If explicitly set to null, allow it to remove the field or set to null
       // For Firestore, to remove a field, you'd use FieldValue.delete()
       // but that requires firebase-admin or more complex client-side handling.
       // For now, setting to null or deleting from object before update.
       delete dataToUpdate.episodeNumber; // Or set to null if your schema expects it: dataToUpdate.episodeNumber = null;
    } else if (typeof dataToUpdate.episodeNumber === 'string') {
        dataToUpdate.episodeNumber = parseInt(dataToUpdate.episodeNumber, 10);
        if (isNaN(dataToUpdate.episodeNumber)) delete dataToUpdate.episodeNumber; // Or set to null
    }

    // Ensure boolean isSeries is handled if present
    if (typeof dataToUpdate.isSeries === 'boolean') {
        // If it's being set to a series, and it had a parentId, clear parent-related fields
        if (dataToUpdate.isSeries && dataToUpdate.parentId) {
            // dataToUpdate.parentId = null; // Or FieldValue.delete()
            // dataToUpdate.episodeNumber = null;
            // dataToUpdate.seriesTitle = null;
        }
    }


    const itemDocRef = doc(db, CONTENT_COLLECTION, itemId);
    await updateDoc(itemDocRef, dataToUpdate);
  } catch (error) {
    console.error('Error updating content item:', error);
    throw error;
  }
};

export const deleteContentItem = async (itemId: string): Promise<void> => {
  try {
    const itemDocRef = doc(db, CONTENT_COLLECTION, itemId);
    await deleteDoc(itemDocRef);
  } catch (error) {
    console.error('Error deleting content item:', error);
    throw error;
  }
};
